from vehicle import *

class Motorbike(Vehicle):
  def __init__(self, model,fuel_amount,fuel_cost_per_km):
    super().__init__(model,fuel_amount,fuel_cost_per_km)
    self.number_of_wheels = 2
    self.number_of_doors = 0

  def get_number_of_wheels(self):
    return self.number_of_wheels

  def get_number_of_doors(self):
    return self.number_of_doors

  def print_motorbike_info(self):
    self.print_info()
    print("Number of wheels: " + str(self.get_number_of_wheels()))
    print("Number of doors: " + str(self.get_number_of_doors()))