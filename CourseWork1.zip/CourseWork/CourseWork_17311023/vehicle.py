class Vehicle:
  def __init__(self, model,fuel_amount,fuel_cost_per_km):
    self.model=model
    self.fuel_amount=fuel_amount
    self.fuel_cost_per_km=fuel_cost_per_km
    self.distance_travelled=0

  def get_model(self):
    return self.model
  
  def get_fuel_amount(self):
    return self.fuel_amount

  def get_fuel_cost_per_km(self):
    return self.fuel_cost_per_km

  def get_distance_travelled(self):
    return self.distance_travelled

  def travel_distance(self, distance):
    if self.fuel_cost_per_km * distance <= self.fuel_amount:
      self.distance_travelled = self.distance_travelled + distance
      self.fuel_amount = self.fuel_amount - self.fuel_cost_per_km * distance
      print("The vehicle distance travelled {0} km".format(self.get_distance_travelled()))
    else:
      print("The vehicle cannot travel the distance")

  def print_info(self):
    print("Model: " + str(self.get_model()))
    print("Fuel amount: " + str(self.get_fuel_amount()))
    print("Fuel cost per km: " + str(self.get_fuel_cost_per_km()))
    print("Distance travelled: " + str(self.get_distance_travelled()))

  def compare_distance_travelled(self, vehicle): 
    if self.get_distance_travelled() < vehicle.get_distance_travelled():
      print("The second vehicle travelled {0} km which is {1} km more than the first vehicle".format(vehicle.get_distance_travelled(), vehicle.get_distance_travelled() - self.get_distance_travelled()))

    elif self.get_distance_travelled() > vehicle.get_distance_travelled():
      print("The first vehicle travelled {0} km which is {1} km more than the second vehicle".format(self.get_distance_travelled(), self.get_distance_travelled()-vehicle.get_distance_travelled()))

    else:
      print("Both vehicles travelled the same distance - {0}km".format(self.get_distance_travelled()))
