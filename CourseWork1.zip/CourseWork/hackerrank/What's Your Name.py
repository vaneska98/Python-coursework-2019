def print_full_name(a, b):
    print("Hello" + " "+ a + " "+ b +"! "+"You just delved into python.")

