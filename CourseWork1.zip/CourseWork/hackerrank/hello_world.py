my_string = "Hello, World!"
print(my_string)
