if __name__ == '__main__':
    n = int(input())
i =0;
while i < n:
    print(i**2)
    i = i + 1